import { StockRepository } from "../ports/StockRepository.js";

export class InMemoryStockRepository extends StockRepository {
  constructor() {
    super();
    this.articles = new Map();
  }

  async findAll() {
    return [...this.articles.values()].map((article) => ({ ...article }));
  }

  async findById(id) {
    const article = this.articles.get(id);
    return article ? { ...article } : null;
  }

  async findByNormalizedName(name) {
    const target = normalizeName(name);
    const article = [...this.articles.values()].find(
      (item) => normalizeName(item.name) === target
    );
    return article ? { ...article } : null;
  }

  async save(article) {
    this.articles.set(article.id, { ...article });
    return { ...article };
  }

  async delete(id) {
    return this.articles.delete(id);
  }
}

function normalizeName(name) {
  return String(name).trim().toLocaleLowerCase("fr");
}
