import { NotificationPort } from "../ports/NotificationPort.js";

export class FakeNotificationAdapter extends NotificationPort {
  constructor() {
    super();
    this.messages = [];
  }

  async notify(message) {
    this.messages.push(message);
    return { delivered: true, message };
  }
}
