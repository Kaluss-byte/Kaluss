import { NotificationPort } from "../ports/NotificationPort.js";

/**
 * Adapter utilisé par le serveur : la notification est simulée.
 * L'interface affiche le message renvoyé dans la réponse HTTP.
 */
export class WebNotificationAdapter extends NotificationPort {
  async notify(message) {
    // L'await rend explicite le point d'extension asynchrone.
    await Promise.resolve();
    return { delivered: true, message };
  }
}
