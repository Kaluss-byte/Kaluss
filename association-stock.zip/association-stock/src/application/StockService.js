import { randomUUID } from "node:crypto";
import { Article } from "../domain/Article.js";

export class StockService {
  constructor({ repository, notifier }) {
    if (!repository) throw new Error("Un repository est nécessaire.");
    if (!notifier) throw new Error("Un notifier est nécessaire.");
    this.repository = repository;
    this.notifier = notifier;
  }

  async listArticles({ search = "", category = "" } = {}) {
    const normalizedSearch = String(search).trim().toLocaleLowerCase("fr");
    const articles = await this.repository.findAll();

    return articles.filter((article) => {
      const matchesSearch = article.name.toLocaleLowerCase("fr").includes(normalizedSearch);
      const matchesCategory = !category || article.category === category;
      return matchesSearch && matchesCategory;
    }).sort((a, b) => a.name.localeCompare(b.name, "fr"));
  }

  async addArticle({ name, category = "Autre", quantity = 0, alertThreshold = 0 }) {
    const normalizedName = String(name ?? "").trim();
    if (!normalizedName) throw new Error("Le nom de l'article est obligatoire.");

    const duplicate = await this.repository.findByNormalizedName(normalizedName);
    if (duplicate) throw new Error("Un article portant ce nom existe déjà.");

    const article = new Article({
      id: randomUUID(),
      name: normalizedName,
      category,
      quantity: Number(quantity),
      alertThreshold: Number(alertThreshold)
    });

    await this.repository.save(article);
    const notification = await this.notifier.notify(`Article « ${article.name} » ajouté.`);
    return { article, notification };
  }

  async changeQuantity(id, { type, amount }) {
    const article = await this.repository.findById(id);
    if (!article) throw new Error("Article introuvable.");

    const numericAmount = Number(amount);
    if (!Number.isInteger(numericAmount) || numericAmount <= 0) {
      throw new Error("La quantité du mouvement doit être un entier strictement positif.");
    }

    if (type === "out") {
      if (numericAmount > article.quantity) {
        throw new Error("Sortie impossible : stock insuffisant.");
      }
      article.quantity -= numericAmount;
    } else if (type === "in") {
      article.quantity += numericAmount;
    } else {
      throw new Error("Type de mouvement invalide.");
    }

    await this.repository.save(article);
    let message = `${type === "in" ? "Entrée" : "Sortie"} de ${numericAmount} unité(s) : ${article.name}.`;
    if (article.isLowStock) message += " Attention : stock faible.";

    const notification = await this.notifier.notify(message);
    return { article, notification };
  }

  async deleteArticle(id) {
    const article = await this.repository.findById(id);
    if (!article) throw new Error("Article introuvable.");

    await this.repository.delete(id);
    const notification = await this.notifier.notify(`Article « ${article.name} » supprimé.`);
    return { notification };
  }
}
