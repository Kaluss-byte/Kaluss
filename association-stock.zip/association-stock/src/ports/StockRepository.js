/**
 * Contrat du port de stockage.
 * Un adapter concret doit fournir ces méthodes.
 */
export class StockRepository {
  async findAll() {
    throw new Error("findAll() doit être implémentée par un adapter.");
  }

  async findById(_id) {
    throw new Error("findById() doit être implémentée par un adapter.");
  }

  async findByNormalizedName(_name) {
    throw new Error("findByNormalizedName() doit être implémentée par un adapter.");
  }

  async save(_article) {
    throw new Error("save() doit être implémentée par un adapter.");
  }

  async delete(_id) {
    throw new Error("delete() doit être implémentée par un adapter.");
  }
}
