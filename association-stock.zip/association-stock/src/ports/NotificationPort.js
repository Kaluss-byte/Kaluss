/**
 * Port de notification. Les adapters doivent respecter ce contrat.
 */
export class NotificationPort {
  async notify(_message) {
    throw new Error("notify() doit être implémentée par un adapter.");
  }
}
