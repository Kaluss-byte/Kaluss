const addForm = document.querySelector("#add-form");
const articleList = document.querySelector("#article-list");
const summary = document.querySelector("#summary");
const message = document.querySelector("#message");
const searchInput = document.querySelector("#search");
const categoryFilter = document.querySelector("#filter-category");

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) }
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Une erreur est survenue.");
  return body;
}

async function loadArticles() {
  try {
    const params = new URLSearchParams();
    if (searchInput.value.trim()) params.set("search", searchInput.value.trim());
    if (categoryFilter.value) params.set("category", categoryFilter.value);
    const { articles } = await api(`/api/articles?${params.toString()}`);
    renderArticles(articles);
  } catch (error) {
    showMessage(error.message, true);
  }
}

function renderArticles(articles) {
  articleList.replaceChildren();
  const lowStockCount = articles.filter((article) => article.quantity <= article.alertThreshold).length;
  summary.textContent = `${articles.length} article(s) affiché(s) · ${lowStockCount} stock(s) faible(s)`;

  if (articles.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "Aucun article trouvé. Ajoutez un article ou modifiez les filtres.";
    articleList.append(empty);
    return;
  }

  for (const article of articles) {
    const card = document.createElement("article");
    card.className = "article-card";

    const top = document.createElement("div");
    top.className = "article-top";
    const details = document.createElement("div");
    const title = document.createElement("h3");
    title.textContent = article.name;
    const meta = document.createElement("p");
    meta.className = "meta";
    meta.textContent = `${article.category} · Seuil d'alerte : ${article.alertThreshold}`;
    details.append(title, meta);

    const quantity = document.createElement("span");
    quantity.className = "quantity";
    quantity.textContent = `${article.quantity} unité(s)`;
    top.append(details, quantity);

    const status = document.createElement("p");
    status.style.margin = "12px 0 0";
    const low = article.quantity <= article.alertThreshold;
    const badge = document.createElement("span");
    badge.className = low ? "low-stock" : "stock-ok";
    badge.textContent = low ? "Stock faible" : "Stock suffisant";
    status.append(badge);

    const actions = document.createElement("div");
    actions.className = "card-actions";
    actions.append(
      actionButton("+ Entrée", async () => moveStock(article.id, "in")),
      actionButton("− Sortie", async () => moveStock(article.id, "out")),
      actionButton("Supprimer", async () => removeArticle(article.id), "remove")
    );

    card.append(top, status, actions);
    articleList.append(card);
  }
}

function actionButton(label, callback, extraClass = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  if (extraClass) button.className = extraClass;
  button.addEventListener("click", callback);
  return button;
}

async function moveStock(id, type) {
  const raw = window.prompt(type === "in" ? "Combien d'unités ajouter ?" : "Combien d'unités retirer ?");
  if (raw === null) return;
  const amount = Number(raw);
  try {
    const result = await api(`/api/articles/${encodeURIComponent(id)}/movements`, {
      method: "POST",
      body: JSON.stringify({ type, amount })
    });
    showMessage(result.notification.message);
    await loadArticles();
  } catch (error) {
    showMessage(error.message, true);
  }
}

async function removeArticle(id) {
  if (!window.confirm("Supprimer cet article ?")) return;
  try {
    const result = await api(`/api/articles/${encodeURIComponent(id)}`, { method: "DELETE" });
    showMessage(result.notification.message);
    await loadArticles();
  } catch (error) {
    showMessage(error.message, true);
  }
}

addForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(addForm);
  const data = Object.fromEntries(formData.entries());
  data.quantity = Number(data.quantity);
  data.alertThreshold = Number(data.alertThreshold);

  try {
    const result = await api("/api/articles", {
      method: "POST",
      body: JSON.stringify(data)
    });
    addForm.reset();
    document.querySelector("#quantity").value = "0";
    document.querySelector("#threshold").value = "5";
    showMessage(result.notification.message);
    await loadArticles();
  } catch (error) {
    showMessage(error.message, true);
  }
});

searchInput.addEventListener("input", loadArticles);
categoryFilter.addEventListener("change", loadArticles);
document.querySelector("#refresh").addEventListener("click", loadArticles);

loadArticles();
