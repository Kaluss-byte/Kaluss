export const CATEGORIES = ["Alimentation", "Boissons", "Fournitures", "Matériel", "Autre"];

export class Article {
  constructor({ id, name, category = "Autre", quantity = 0, alertThreshold = 0 }) {
    const normalizedName = String(name ?? "").trim();

    if (!normalizedName) {
      throw new Error("Le nom de l'article est obligatoire.");
    }
    if (!Number.isInteger(quantity) || quantity < 0) {
      throw new Error("La quantité doit être un entier positif ou nul.");
    }
    if (!Number.isInteger(alertThreshold) || alertThreshold < 0) {
      throw new Error("Le seuil d'alerte doit être un entier positif ou nul.");
    }
    if (!CATEGORIES.includes(category)) {
      throw new Error("Catégorie invalide.");
    }

    this.id = id;
    this.name = normalizedName;
    this.category = category;
    this.quantity = quantity;
    this.alertThreshold = alertThreshold;
  }

  get isLowStock() {
    return this.quantity <= this.alertThreshold;
  }
}
