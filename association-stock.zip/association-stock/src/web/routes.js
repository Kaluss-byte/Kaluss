import { Router } from "express";
import { CATEGORIES } from "../domain/Article.js";

export function createRoutes(service) {
  const router = Router();

  router.get("/health", (_req, res) => res.json({ status: "ok" }));

  router.get("/articles", async (req, res, next) => {
    try {
      const articles = await service.listArticles({
        search: req.query.search ?? "",
        category: req.query.category ?? ""
      });
      res.json({ articles });
    } catch (error) {
      next(error);
    }
  });

  router.get("/categories", (_req, res) => res.json({ categories: CATEGORIES }));

  router.post("/articles", async (req, res) => {
    try {
      const result = await service.addArticle(req.body);
      res.status(201).json(result);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  router.post("/articles/:id/movements", async (req, res) => {
    try {
      const result = await service.changeQuantity(req.params.id, req.body);
      res.json(result);
    } catch (error) {
      const status = error.message === "Article introuvable." ? 404 : 400;
      res.status(status).json({ error: error.message });
    }
  });

  router.delete("/articles/:id", async (req, res) => {
    try {
      const result = await service.deleteArticle(req.params.id);
      res.json(result);
    } catch (error) {
      const status = error.message === "Article introuvable." ? 404 : 400;
      res.status(status).json({ error: error.message });
    }
  });

  return router;
}
