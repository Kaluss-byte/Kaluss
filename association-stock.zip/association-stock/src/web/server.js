import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { InMemoryStockRepository } from "../adapters/InMemoryStockRepository.js";
import { WebNotificationAdapter } from "../adapters/WebNotificationAdapter.js";
import { StockService } from "../application/StockService.js";
import { createRoutes } from "./routes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createApp({ service } = {}) {
  const stockService = service ?? new StockService({
    repository: new InMemoryStockRepository(),
    notifier: new WebNotificationAdapter()
  });

  const app = express();
  app.use(express.json());
  app.use(express.static(path.resolve(__dirname, "../public")));
  app.use("/api", createRoutes(stockService));

  app.use((error, _req, res, _next) => {
    console.error(error);
    res.status(500).json({ error: "Erreur interne du serveur." });
  });

  return app;
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === __filename;
if (isDirectRun) {
  const app = createApp();
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Association Stock disponible sur http://localhost:${port}`));
}
