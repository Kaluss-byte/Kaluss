import { afterEach, describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../src/web/server.js";
import { InMemoryStockRepository } from "../src/adapters/InMemoryStockRepository.js";
import { FakeNotificationAdapter } from "../src/adapters/FakeNotificationAdapter.js";
import { StockService } from "../src/application/StockService.js";

describe("API HTTP (intégration)", () => {
  let app;

  afterEach(() => {
    app = undefined;
  });

  it("permet d'ajouter puis de retrouver un article via HTTP", async () => {
    const service = new StockService({
      repository: new InMemoryStockRepository(),
      notifier: new FakeNotificationAdapter()
    });
    app = createApp({ service });

    const createResponse = await request(app)
      .post("/api/articles")
      .send({ name: "Cartons", category: "Matériel", quantity: 12, alertThreshold: 3 });

    expect(createResponse.status).toBe(201);
    expect(createResponse.body.article.name).toBe("Cartons");

    const listResponse = await request(app).get("/api/articles");
    expect(listResponse.status).toBe(200);
    expect(listResponse.body.articles).toHaveLength(1);
    expect(listResponse.body.articles[0].quantity).toBe(12);
  });

  it("refuse une sortie qui dépasse le stock via HTTP", async () => {
    const service = new StockService({
      repository: new InMemoryStockRepository(),
      notifier: new FakeNotificationAdapter()
    });
    app = createApp({ service });

    const created = await request(app)
      .post("/api/articles")
      .send({ name: "Boîtes", category: "Matériel", quantity: 2, alertThreshold: 0 });

    const response = await request(app)
      .post(`/api/articles/${created.body.article.id}/movements`)
      .send({ type: "out", amount: 3 });

    expect(response.status).toBe(400);
    expect(response.body.error).toContain("stock insuffisant");
  });
});
