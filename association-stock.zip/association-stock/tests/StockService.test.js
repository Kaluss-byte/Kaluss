import { beforeEach, describe, expect, it } from "vitest";
import { InMemoryStockRepository } from "../src/adapters/InMemoryStockRepository.js";
import { FakeNotificationAdapter } from "../src/adapters/FakeNotificationAdapter.js";
import { StockService } from "../src/application/StockService.js";

describe("StockService", () => {
  let repository;
  let notifier;
  let service;

  beforeEach(() => {
    repository = new InMemoryStockRepository();
    notifier = new FakeNotificationAdapter();
    service = new StockService({ repository, notifier });
  });

  it("ajoute un article valide", async () => {
    const { article } = await service.addArticle({
      name: "Gobelets",
      category: "Matériel",
      quantity: 20,
      alertThreshold: 5
    });

    expect(article.name).toBe("Gobelets");
    expect((await service.listArticles()).length).toBe(1);
  });

  it("refuse un nom vide", async () => {
    await expect(service.addArticle({ name: "   " })).rejects.toThrow(
      "Le nom de l'article est obligatoire."
    );
  });

  it("refuse les doublons même si la casse diffère", async () => {
    await service.addArticle({ name: "Gobelets" });
    await expect(service.addArticle({ name: " gObElEtS " })).rejects.toThrow(
      "Un article portant ce nom existe déjà."
    );
  });

  it("refuse une sortie supérieure au stock sans modifier la quantité", async () => {
    const { article } = await service.addArticle({
      name: "Sacs",
      quantity: 4,
      alertThreshold: 1
    });

    await expect(service.changeQuantity(article.id, { type: "out", amount: 5 }))
      .rejects.toThrow("Sortie impossible : stock insuffisant.");

    expect((await repository.findById(article.id)).quantity).toBe(4);
  });

  it("met à jour la quantité lors d'une entrée", async () => {
    const { article } = await service.addArticle({ name: "Cahiers", quantity: 10 });
    const result = await service.changeQuantity(article.id, { type: "in", amount: 5 });
    expect(result.article.quantity).toBe(15);
  });

  it("signale un stock faible lorsque le seuil est atteint", async () => {
    const { article } = await service.addArticle({
      name: "Stylos",
      quantity: 6,
      alertThreshold: 5
    });

    const result = await service.changeQuantity(article.id, { type: "out", amount: 1 });
    expect(result.article.isLowStock).toBe(true);
    expect(result.notification.message).toContain("stock faible");
  });

  it("refuse un mouvement de quantité nulle", async () => {
    const { article } = await service.addArticle({ name: "Feuilles", quantity: 5 });
    await expect(service.changeQuantity(article.id, { type: "in", amount: 0 }))
      .rejects.toThrow("La quantité du mouvement doit être un entier strictement positif.");
  });
});
